# Date Invitation Website

This is a free, self-contained website. It needs no server, database, paid hosting, or external libraries.

## Run it
Open `index.html` in any modern web browser.

## Put it online for free
You can upload the folder to a free static-hosting service such as GitHub Pages, Netlify, or Cloudflare Pages.

## Customize it
Open `index.html` in a text editor and change the question, wording, activity choices, emojis, and styling.

The playful "No" button dodges a few times, then becomes clickable so the recipient can always give an honest answer.
